import './App.css'
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Signup, Login, Profile, VerifyEmail, ForgetPassword, ResetPassword } from './pages';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function App() {

  return (
    <>
      <Router>
        <Routes>
          <Route path='/' element={<Signup />}></Route>
          <Route path='/login' element={<Login />}></Route>
          <Route path='/dashboard' element={<Profile />}></Route>
          <Route path='/otp/verify' element={<VerifyEmail />}></Route>
          <Route path='/forgot-password' element={<ForgetPassword />}></Route>
          <Route path='/reset-password/:uid/:token' element={<ResetPassword />}></Route>
        </Routes>

      </Router>
      <ToastContainer />

    </>
  )
}

export default App;

