import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

interface FormData {
    first_name: string;
    last_name: string;
    email: string;
    password: string;
    password2: string;
}

const Signup = () => {
    const navigate = useNavigate();
    const [formData, setFormData] = useState<FormData>({
        first_name: '',
        last_name: '',
        email: '',
        password: '',
        password2: '',
    });
    const [error, setError] = useState<string>("");

    const { first_name, last_name, email, password, password2 } = formData;

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
    };

    const handleGoogleSignIn = async (response: { credential: string }) => {
        try {
            const res = await axios.post("http://localhost:8000/api/v1/auth/google/", {
                access_token: response.credential,
            });
            if (res.status === 200) {
                const data = res.data;
                const user = {
                    email: data.email,
                    names: data.full_name,
                };
                localStorage.setItem("user", JSON.stringify(user));
                localStorage.setItem("access", JSON.stringify(data.access_token));
                localStorage.setItem("refresh", JSON.stringify(data.refresh_token));

                toast.success("Login successful");
                navigate("/dashboard");
            }
        } catch (err) {
            console.error("Google Sign-In Error:", err);
            setError("Failed to sign in with Google");
        }
    };

    useEffect(() => {
        if (window.google && google.accounts) {
            google.accounts.id.initialize({
                client_id: import.meta.env.VITE_CLIENT_ID,
                callback: handleGoogleSignIn,
            });
            google.accounts.id.renderButton(
                document.getElementById("signInDiv"),
                {
                    theme: "outline",
                    size: "large",
                    text: "continue_with",
                    shape: "circle",
                    width: "280",
                }
            );
        } else {
            console.warn("Google accounts SDK not loaded");
        }
    }, []);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setError("");  // Reset error before validation

        if (!first_name || !last_name || !email || !password || !password2) {
            return setError("All fields are required");
        }

        if (password !== password2) {
            return setError("Passwords do not match");
        }

        try {
            const res = await axios.post("http://localhost:8000/api/v1/auth/register/", formData);
            if (res.status === 201) {
                toast.success(res.data.message);
                navigate("/otp/verify");
            }
        } catch (err) {
            console.error("Registration Error:", err);
            setError("Registration failed. Please try again.");
        }
    };
    return (
        <div className="mt-8 max-w-md mx-auto bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-bold mb-4 text-center text-gray-800">Sign Up</h2>

            <form onSubmit={handleSubmit} className="space-y-4">
                {/* First Name */}
                <div>
                    <label htmlFor="first_name" className="block text-sm font-medium text-gray-700">
                        First Name
                    </label>
                    <input
                        type="text"
                        name="first_name"
                        id="first_name"
                        value={first_name}
                        onChange={handleChange}
                        className="mt-1 p-2 w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        required
                    />
                </div>

                {/* Last Name */}
                <div>
                    <label htmlFor="last_name" className="block text-sm font-medium text-gray-700">
                        Last Name
                    </label>
                    <input
                        type="text"
                        name="last_name"
                        id="last_name"
                        value={last_name}
                        onChange={handleChange}
                        className="mt-1 p-2 w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        required
                    />
                </div>

                {/* Email */}
                <div>
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                        Email
                    </label>
                    <input
                        type="email"
                        name="email"
                        id="email"
                        value={email}
                        onChange={handleChange}
                        className="mt-1 p-2 w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        required
                    />
                </div>

                {/* Password */}
                <div>
                    <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                        Password
                    </label>
                    <input
                        type="password"
                        name="password"
                        id="password"
                        value={password}
                        onChange={handleChange}
                        className="mt-1 p-2 w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        required
                    />
                </div>
                {/* Confirm Password */}
                <div>
                    <label htmlFor="password2" className="block text-sm font-medium text-gray-700">
                        Confirm Password
                    </label>
                    <input
                        type="password"
                        name="password2"
                        id="password2"
                        value={password2}
                        onChange={handleChange}
                        className="mt-1 p-2 w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                        required
                    />
                </div>
                <p>{error ? error : ""}</p>
                {/* Submit Button */}
                <div>
                    <button
                        type="submit"
                        className="w-full py-2 px-4 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                        Sign In
                    </button>
                </div>

                {/* Google Sign-In Button */}
                <div className="text-center mt-4  w-full py-2 px-4 text-white font-semibold rounded-md  focus:outline-none focus:ring-2 focus:ring-offset-2 ">
                    <div className="googleContainer max-w-md  mx-auto " id="signInDiv" ></div>
                </div>

                {/* Sign In Link */}
                <div className="text-center mt-4">
                    <p className="text-sm text-gray-600">
                        Already have an account?{' '}
                        <Link to="/login" className="text-blue-600 hover:underline">
                            Sign In
                        </Link>
                    </p>
                </div>
            </form>

        </div>
    )
}
export default Signup