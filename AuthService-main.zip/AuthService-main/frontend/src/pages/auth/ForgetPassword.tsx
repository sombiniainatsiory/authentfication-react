import React, { useState } from 'react';
import axiosInstance from '../../utils/axiosInstance';
import { toast } from 'react-toastify';
const ForgetPassword = () => {
    const [email, setEmail] = useState('');
    const [submitted, setSubmitted] = useState(false);

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setEmail(e.target.value);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (email) {
            const res = await axiosInstance.post("/auth/password-reset/", { "email": email })
            if (res.status === 200) {
                toast.success("A link to reset your password has be sent to your email")
            }
        }
        setEmail("");
        setSubmitted(true);
    };

    return (
        <div className="mt-8 max-w-md mx-auto bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-bold mb-4 text-center text-gray-800">Forgot Password</h2>
            {submitted ? (
                <div className="text-green-500 font-semibold text-center">
                    If an account exists with this email, you will receive instructions to reset your password.
                </div>
            ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                    {/* Email Input */}
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                            Enter your email
                        </label>
                        <input
                            type="email"
                            name="email"
                            id="email"
                            value={email}
                            onChange={handleChange}
                            className="mt-1 p-2 w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                            required
                        />
                    </div>

                    {/* Submit Button */}
                    <div>
                        <button
                            type="submit"
                            className="w-full py-2 px-4 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                        >
                            Send Reset Instructions
                        </button>
                    </div>

                    {/* Back to Sign In */}
                    <div className="text-center mt-4">
                        <a href="/login" className="text-sm text-blue-600 hover:underline">
                            Back to Log In
                        </a>
                    </div>
                </form>
            )}
        </div>
    );
}
export default ForgetPassword