import axios from 'axios';
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { toast } from 'react-toastify';

const VerifyEmail = () => {
    const [otp, setOtp] = useState('');
    const [submitted, setSubmitted] = useState(false);
    const navigate = useNavigate();

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setOtp(e.target.value);
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (otp) {
            const response = await axios.post("http://localhost:8000/api/v1/auth/verify-email/", { "otp": otp })
            if (response.status === 200) {
                navigate("/login");
                toast.success(response.data.message);
            }
        }
        setSubmitted(true);
    };

    const handleResendOtp = () => {
        toast("Rensend OTP");
    };

    return (
        <div className="mt-8 max-w-md mx-auto bg-white p-6 rounded-lg shadow-md">
            <h2 className="text-2xl font-bold mb-4 text-center text-gray-800">OTP Verification</h2>
            {submitted ? (
                <div className="text-green-500 font-semibold text-center">
                    OTP Verified Successfully!
                </div>
            ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                    {/* OTP Input */}
                    <div>
                        <label htmlFor="otp" className="block text-sm font-medium text-gray-700">
                            Enter OTP
                        </label>
                        <input
                            type="text"
                            name="otp"
                            id="otp"
                            value={otp}
                            onChange={handleChange}
                            className="mt-1 p-2 w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                            required
                            maxLength={6}
                        />
                    </div>

                    {/* Submit Button */}
                    <div>
                        <button
                            type="submit"
                            className="w-full py-2 px-4 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                        >
                            Verify OTP
                        </button>
                    </div>

                    {/* Resend OTP Button */}
                    <div className="text-center mt-4">
                        <button
                            type="button"
                            onClick={handleResendOtp}
                            className="text-sm text-blue-600 hover:underline"
                        >
                            Resend OTP
                        </button>
                    </div>
                </form>
            )}
        </div>
    );
}
export default VerifyEmail