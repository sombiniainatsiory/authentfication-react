import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../../utils/axiosInstance";
import { toast } from "react-toastify";

const Profile = () => {
    const navigate = useNavigate();
    const user = JSON.parse(localStorage.getItem("user")!);

    useEffect(() => {
        if (!user) {
            navigate("/login");
        } else {
            getProfileData();
        }
    }, []);

    const getProfileData = async () => {
        try {
            const res = await axiosInstance.get("/auth/profile/");
            if (res.status === 200) {
                console.log(res.data);
            }
        } catch (error) {
            console.error("Failed to load profile data", error);
        }
    };

    const handleLogout = async () => {
        const refresh = JSON.parse(localStorage.getItem("refresh")!);
        try {
            const res = await axiosInstance.post("/auth/logout/", { refresh_token: refresh });
            if (res.status === 200) {
                localStorage.removeItem("access");
                localStorage.removeItem("refresh");
                localStorage.removeItem("user");
                navigate("/login");
                toast.success("Logout successful");
            }
        } catch (error) {
            toast.error("Failed to log out");
        }
    };

    return (
        <>
            <div className="mt-8 max-w-md mx-auto bg-white p-6 rounded-lg shadow-md">
                <p>Welcome {user && user.names} ! </p>
                <div className="text-center mt-4">
                    <button
                        onClick={handleLogout}
                        type="button"
                        className="w-full py-2 px-4 bg-red-600 text-white font-semibold rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                    >
                        Log out
                    </button>
                </div>
            </div>

        </>
    )
}
export default Profile