import { useState } from 'react';
import { useParams, useNavigate } from "react-router-dom";
import { toast } from 'react-toastify';
import AxiosInstance from '../../utils/axiosInstance';

const ResetPassword = () => {
  const navigate = useNavigate();
  const { uid, token } = useParams();
  const [newPasswords, setNewPasswords] = useState({
    password: "",
    confirm_password: "",
  });
  const { password, confirm_password } = newPasswords;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setNewPasswords({ ...newPasswords, [name]: value });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (password !== confirm_password) {
      toast.error("Passwords do not match");
      return;
    }

    const data = {
      password,
      confirm_password,
      uidb64: uid,
      token,
    };

    try {
      const res = await AxiosInstance.patch('auth/set-new-password/', data);
      if (res.status === 200) {
        toast.success(res.data.message);
        navigate('/login');
      }
    } catch (error) {
      console.error("Password reset failed:", error);
      toast.error("Failed to reset password. Please try again.");
    }
  };

  return (
    <div>
      <div className="mt-8 max-w-md mx-auto bg-white p-6 rounded-lg shadow-md">
        <h2 className="text-2xl font-bold mb-4 text-center text-gray-800">Reset Password</h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className='form-group'>
            <label htmlFor="password" className="block text-sm font-medium text-gray-700">
              New Password:
            </label>
            <input
              type="password"
              id="password"
              name="password"
              value={password}
              onChange={handleChange}
              className="mt-1 p-2 w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>

          <div className='form-group'>
            <label htmlFor="confirm_password" className="block text-sm font-medium text-gray-700">
              Confirm New Password:
            </label>
            <input
              type="password"
              id="confirm_password"
              name="confirm_password"
              value={confirm_password}
              onChange={handleChange}
              className="mt-1 p-2 w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
              required
            />
          </div>

          <button type='submit' className='vbtn'>Submit</button>
        </form>
      </div>
    </div>
  );
}

export default ResetPassword;
