import React, { useState, CSSProperties } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import axios from 'axios';
import { HashLoader } from 'react-spinners';

const override: CSSProperties = {
    display: "block",
    margin: "0 auto",
    borderColor: "red",
    zIndex: "5"
};


interface FormData {
    email: string;
    password: string;
}

const Login = () => {
    const [formData, setFormData] = useState<FormData>({
        email: '',
        password: '',
    });
    const [error, setError] = useState<String>("");
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const navigate = useNavigate();

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target;
        setFormData((prev) => ({ ...prev, [name]: value }));
    };

    const handleGoogleSignIn = () => {
        console.log("Connexion avec Google");
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        const { email, password } = formData;
        if (!email || !password) {
            setError("Email and password are required");
        }
        else {
            setIsLoading(true);
            const res = await axios.post("http://localhost:8000/api/v1/auth/login/", formData);
            const response = res.data;
            setIsLoading(false);

            console.log(response);
            console.log(response.access_token);

            const user = {
                "email": response.email,
                "names": response.full_name
            }
            if (res.status === 200) {
                localStorage.setItem("user", JSON.stringify(user));
                localStorage.setItem("access", JSON.stringify(response.access_token))
                localStorage.setItem("refresh", JSON.stringify(response.refresh_token))
                navigate("/dashboard");
                toast.success("Login successfull");
            }
        }
    };
    return (
        <>  <HashLoader
            loading={isLoading}
            cssOverride={override}
            size={150}
            color='green'
            aria-label="Loading Spinner"
            data-testid="loader"
        />
            <div className="mt-8 max-w-md mx-auto bg-white p-6 rounded-lg shadow-md">
                <h2 className="text-2xl font-bold mb-4 text-center text-gray-800">Sign In</h2>


                <form onSubmit={handleSubmit} className="space-y-4">

                    {/* Email */}
                    <div>
                        <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                            Email
                        </label>
                        <input
                            type="email"
                            name="email"
                            id="email"
                            value={formData.email}
                            onChange={handleChange}
                            className="mt-1 p-2 w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                            required
                        />
                    </div>

                    {/* Password */}
                    <div>
                        <label htmlFor="password" className="block text-sm font-medium text-gray-700">
                            Password
                        </label>
                        <input
                            type="password"
                            name="password"
                            id="password"
                            value={formData.password}
                            onChange={handleChange}
                            className="mt-1 p-2 w-full border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
                            required
                        />
                    </div>
                    {/* Forgot Password Link */}
                    <div className="text-right">
                        <Link to="/forgot-password" className="text-sm text-blue-600 hover:underline">
                            Forgot password?
                        </Link>
                    </div>
                    {/* Submit Button */}
                    {error ?? <p>{error}</p>}
                    <div>
                        <button
                            type="submit"
                            className="w-full py-2 px-4 bg-blue-600 text-white font-semibold rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                        >
                            Sign In
                        </button>
                    </div>
                    {/* Google Sign-In Button */}

                    <div className="text-center mt-4">
                        <button
                            type="button"
                            onClick={handleGoogleSignIn}
                            className="w-full py-2 px-4 bg-red-600 text-white font-semibold rounded-md hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
                        >
                            Sign In with Google
                        </button>
                    </div>

                    {/* Sign Up Link */}
                    <div className="text-center mt-4">
                        <p className="text-sm text-gray-600">
                            Don't have an account?{' '}
                            <Link to="/" className="text-blue-600 hover:underline">
                                Sign Up
                            </Link>
                        </p>
                    </div>
                </form>
            </div>
        </>
    )
}
export default Login