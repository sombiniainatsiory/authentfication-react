import Signup from "./auth/Signup";
import Login from "./auth/Login";
import Profile from "./auth/Profile";
import ForgetPassword from "./auth/ForgetPassword";
import VerifyEmail from "./auth/VerifyEmail";
import ResetPassword from "./auth/ResetPassword";

export {
    Signup,
    Login,
    Profile,
    ForgetPassword,
    VerifyEmail,
    ResetPassword
}