import axios from "axios";
import dayjs from "dayjs";
import { jwtDecode } from "jwt-decode";

// Utility function to safely parse JSON
const parseJSON = (value: any) => {
    try {
        return JSON.parse(value);
    } catch (e) {
        return null; // Return null if JSON parsing fails
    }
};

// Retrieve tokens from localStorage
const token = parseJSON(localStorage.getItem("access")) || "";
const refresh_token = parseJSON(localStorage.getItem("refresh")) || "";
console.log("Access Token:", token);
console.log("Refresh Token:", refresh_token);

// Base URL for API
const baseUrl = "http://localhost:8000/api/v1";

// Create Axios instance with default headers
const axiosInstance = axios.create({
    baseURL: baseUrl,
    headers: {
        "Content-type": "application/json",
        Authorization: token ? `Bearer ${token}` : undefined,
    }
});

// Axios request interceptor to add token and handle expiration
axiosInstance.interceptors.request.use(async (req) => {
    if (token) {
        const user = jwtDecode<{ exp: number }>(token);
        const isExpired = dayjs.unix(user.exp).isBefore(dayjs());

        if (!isExpired) {
            return req;
        } else {
            try {
                const res = await axios.post(`${baseUrl}/auth/token/refresh/`, { refresh: refresh_token });

                if (res.status === 200 && res.data.access) {
                    localStorage.setItem("access", JSON.stringify(res.data.access));
                    req.headers.Authorization = `Bearer ${res.data.access}`;
                    return req;
                } else {
                    await axios.post(`${baseUrl}/auth/logout/`, { refresh_token });
                    localStorage.removeItem("access");
                    localStorage.removeItem("refresh");
                    localStorage.removeItem("user");
                }
            } catch (error) {
                console.error("Error refreshing token:", error);
                return Promise.reject(error);
            }
        }
    }
    return req;
}, (error) => {
    return Promise.reject(error);
});

export default axiosInstance;
