from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

from home.serializer import ProductSerializer
from .models import Product

class ProductView(APIView):
    def get(self, request):
        products = [
            {
                "name": product.name, 
                "quantity": product.quantity, 
                "price": product.price
            } for product in Product.objects.all()
        ]
        return Response(products, status=status.HTTP_200_OK)
        
    def post(self, request):
        serializer = ProductSerializer(data=request.data)
        if serializer.is_valid(raise_exception=True):
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        