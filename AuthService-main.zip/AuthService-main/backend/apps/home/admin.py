from django.contrib import admin

from home.models import Product

# Register your models here.
admin.site.register(Product)