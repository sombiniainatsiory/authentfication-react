from django.db import models

class Product(models.Model):
    name = models.CharField(max_length=100)
    quantity = models.IntegerField(default=0)
    price = models.FloatField(default=0)
    class Meta:
        app_label = 'accounts'